#pragma once

// Fill the registry with initial items
void init_tool_registry();
