#pragma once
// Render the main menu to Serial (for now)
void showMainMenu();
