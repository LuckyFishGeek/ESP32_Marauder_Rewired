# Adafruit_InternalFlash

This library provide a convenient way to use internal flash for FAT FileSystem. Currently support mcu cores are:

- SAMD21 from [adafruit/ArduinoCore-samd](https://github.com/adafruit/ArduinoCore-samd)
