#include "../src/bb_spi_lcd.cpp"
#include "../src/bb_parallel.cpp"

